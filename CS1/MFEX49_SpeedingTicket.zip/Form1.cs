﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX49_SpeedingTicket
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            //I learned that using the properties menu on the other page, you can make labels start hidden!
        }


        #region useless
        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        #endregion
        private void button1_Click(object sender, EventArgs e)
        {
            //BUTTON IS CLICKED HERE
            double limit = Convert.ToDouble(textBox1.Text);
            double going = Convert.ToDouble(textBox2.Text);

            if (limit>=1 && limit <=100 && going>limit && going >= 1 && going <= 200) 
            {
                double grade = GetGrade();
                double excess = GetExcess(limit, going);
                double overFee = GetOverFee(excess);//I did so many methods to adhere to the prompt
                double gradeTax = GetGTax(grade, excess);
                double total = 75 + overFee + gradeTax;

                #region Display
                excesslabel.Text = "MPH over limit: " + excess;
                excesslabel.Visible = true;

                label5.Visible = true;

                label4.Text = "Fee proportional to overspeed: $" + overFee;
                label4.Visible = true;

                label6.Text = "Grade specific fee: $" + gradeTax;
                label6.Visible = true;

                label7.Text = "Total of all fees: $" + total;
                label7.Visible = true;
                #endregion
            }
            else
            {
                //label7.Text = "Invalid input. Please try again!";
                // label7.Visible = true;
                //I got rid of these in favor of message box

                MessageBox.Show("Invalid! Come on knucklehead!");
            }
            
        }

        public double GetGTax(double grade, double excess)
        {
           
            double gradeTax = 0;
            if (grade == 0 || grade == 1) //I learned that the index for the dropdowns starts at 0 and not 1 so that broke most of this.
            {
                if (excess < 20) //We talked about me not using a switch statement in class dont yell at me for the prompt
                {
                    gradeTax = -50;
                }
                else
                {
                    gradeTax = 100;
                }
            }

            else if (grade == 2)
            {
                if (excess < 20)
                {
                    gradeTax = 0;
                }
                else
                {
                    gradeTax = 100;
                }
            }
            
            else if (grade == 3)
            {
                if (excess <= 20)
                {
                    gradeTax = 50;
                }
                else
                {
                    gradeTax = 200;
                }
            }
            return gradeTax;
        }
        
        public double GetOverFee(double excess)
        {
            return ((int)excess / (int)5) * 87.50; //I had to do casting here to round easier otherwise the output would be wrong
        }
        
        public double GetExcess(double limit, double going)
        {
            return going - limit;
        }
        public double GetGrade()
        {
            return comboBox1.SelectedIndex;
        }

        #region useless2
        private void excesslabel_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label7_Click(object sender, EventArgs e)
        {

        }

        private void checkBox3_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox2_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void checkBox4_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        #endregion
    }
}

/*
 Create an application called Ex49_SpeedingTicket: Your program should implement several methods to help produce the proper 
fine for a speeding ticket. As always use proper variable names and comment your code! You may make your program a windows 
form or a console application.  Be sure to implement the following . . . recursion so a user can't type in a negative value
in an AskUserFordouble method, recursion in a Switch method that performs all the calculations so a user can't enter a classification
larger than 4, and casting (or strategically don't cast).  Also, please allow for the functionality of re-running your project 
multiple times without having to stop and start your project over and over again.  

Speeding ticket:
Consider the situation of issuing parking tickets on campus and determining the fines associated with the ticket.

All students are charged an initial $75.00 when ticketed. Additional charges are based on how much over the speed limit the 
ticket reads. There is a 35 miles per hour(MPH) speed limit on most streets on campus. Two roads are posed with a speed limit 
of 15 MPH. Fines are expensive on campus. After the initial $75 fee, an extra $87.50 is charged for every 5 MPH student are 
clocked over the speed limit.

The traffic office feels seniors have been around for a while and should know better than to speed on campus. They have even
more fees for their fine. At the same time, they try to cut freshmen a little slack. Seniors are charged an extra $50 when 
they get caught speeding unless they are traveling more than 20 MPH over the speed limit. Then they are charged an extra $200.

If freshmen and sophomores are exceeding the speed limit by less than 20 MPH, they get a $50 deduction off their fines. But,
freshmen, sophomores, and juniors traveling 20 MPH or more are fined an additional $100.
 */