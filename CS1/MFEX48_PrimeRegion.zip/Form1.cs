﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX48_PrimeRegion
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label3.Visible = false;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            label3.Visible = false;
            int bottom = Convert.ToInt32(textBox1.Text);
            int top = Convert.ToInt32(textBox2.Text);
            if (bottom<top&&bottom>1) //I learned ways to make this more efficent by going through 3 different conditions
            {
                int counter = 0;
                for (int i = bottom; i <= top; i++)
                {
                    bool isPrime = IsPrime(i);
                    if (isPrime)
                    {
                        counter++;
                    }
                }
                label3.Text = "There are " + counter + " primes between " + bottom + " and " + top + "."; //In my last program, I didn't realize this existed. Now that i know it does, it makes evereything so much easier!
                label3.Visible = true;
            }
            else //This is the closest solution I see for recursion. I know that it's minimal but it works. I love how the windows forms just keeps running.
            {
                label3.Text = "One of those numbers is invalid. Try again!";
                label3.Visible = true;
            }
        }

        public static bool IsPrime(int num)
        {
            bool isPrime = true;
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0)
                {
                    isPrime = false;
                }
            }
            return isPrime;
        }

        private void label4_Click(object sender, EventArgs e)
        {

        }
    }
}

/*
Create an application called looping  Ex48_PrimeRegion. Reuse the method IsItPrime(int n) 
from Ex47_PrimeNumber to help create a method that finds the number of primes found between two 
numbers(inclusive, that means that it includes the two numbers) entered by the user, then display the 
number of primes in that region.  
Please allow for the functionality of repeating your program without quitting out of it.
 */
