﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX50_PrimeFactors
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        
        
        private void button1_Click(object sender, EventArgs e)
        {

            label2.Text = "";    
            int num = Convert.ToInt32(textBox1.Text);

            if (num >= 4)
            {
                for (int i = 2; i <= num; i++) //We went over this in class, it works better than the way your psuedo code said
                {
                    while (num % i == 0)
                    {
                        label2.Text = label2.Text + i + ", ";
                        num = num / i; 
                    }
                    //Dont need to check primeness because the lowest factor will always be prime
                }


                label2.Text = label2.Text.Remove(label2.Text.Length - 2); //I know you hate this lol but i could not find a way to do it another way
            }
            else
            {
                label2.Text = "Invalid. Try again!";
            }

            


            
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}


//Create an application called EX50_PrimeFactors. Write code that displays the prime factors of an integer entered by the user.
//If a number has a prime factor that happens more than once, it should be printed more than once.  Each factor should be separated
//by a comma(,) without one on the end.  Note: There is NOT a comma after the 7 in the example below.  Do not allow the user to
//enter in a negative value, and allow the user to re-run the program without quitting out of the program and restarting it
//(a sentinel controlled loop "Enter 0 to exit" would be a nice touch).