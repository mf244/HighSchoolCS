﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX47_PrimeNumber
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label2.Visible = false; //I really feel like labels should start hidden
            label3.Visible = false;
            label4.Visible = false;
        }

        

        private void button1_Click(object sender, EventArgs e)
        {
            label2.Visible = false;
            label3.Visible = false;
            label4.Visible = false;
            int numb = Convert.ToInt32(textBox1.Text);
            if (numb == 1 || numb <= 0)
            {
                label4.Visible = true; //I believe this is all the recursion I need as pressing 0 to exit doesnt work in windows forms
            }
            else
            {
                bool isPrime = IsPrime(numb); 
                if (isPrime)
                {
                    label2.Visible = true;
                }
                else
                {
                    label3.Visible = true;
                }
            }
            
        }


        public static bool IsPrime(int num)
        {
            bool isPrime = true;
            for (int i = 2; i < num; i++)
            {
                if (num % i == 0) //This took me a while to figure out
                {
                    isPrime = false;
                }
            }
            return isPrime;
        }
    }
}
