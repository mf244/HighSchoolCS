﻿//This form way by far the toughest to get working as there were so many different issues
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration; 
using System.Data.SqlClient; 
namespace SeeSharpCode
{
    public partial class Add : Form
    {

        string connectionString; 
        SqlConnection connection;
        public Add()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["SeeSharpCode.Properties.Settings.BasicBusinessConnectionString"].ConnectionString; 

        }

        private void button1_Click(object sender, EventArgs e)
        {

            //This code commented out did NOT work, but I left it here so you could see my failed attempt

            /*
            connection = new SqlConnection(connectionString);
            connection.Open(); //Opens a new connection to the ConnectionString (the DB)

            string Name = textBox1.Text;
            string EmployeeID = textBox2.Text;
            string PayGrade = textBox3.Text;
            string Address = textBox4.Text;
            string Hourly = textBox5.Text;
            string Rate = textBox6.Text;
            string Hours = textBox7.Text;
            string Yearly = textBox8.Text;


            ExecuteScalar(connectionString, "INSERT INTO table(Name, EmployeeID, PayGrade, Address, Hourly, Rate, Hours, Yearly) VALUES('" + Name + "', '" + EmployeeID + "', '" + PayGrade + "', '" + Address + "', '" + Hourly + "', '" + Rate + "', '" + Hours + "', '" + Yearly + "')"); //This is the line where the SQL statement is set+", "+ this is the command that will be run against the DB

            */

            string cmdString = "INSERT INTO EmpInfo (Name, EmployeeID, PayGrade, Address, Hourly, Rate, Hours, Yearly) VALUES (@val1, @val2, @val3, @val4, @val5, @val6, @val7, @val8)"; 
            //Creates a command with variables that can actually be changed


            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                using (SqlCommand comm = new SqlCommand())
                {

                    decimal tb6 = Convert.ToDecimal(textBox6.Text); //Converts  number input into the right format for DB
                    decimal tb7 = Convert.ToDecimal(textBox7.Text);
                    decimal tb8 = Convert.ToDecimal(textBox8.Text);
                    
                    comm.Connection = conn;
                    comm.CommandText = cmdString;
                    
                    comm.Parameters.AddWithValue("@val1", textBox1.Text); //Assigns all the command variables
                    comm.Parameters.AddWithValue("@val2", textBox2.Text);
                    comm.Parameters.AddWithValue("@val3", textBox3.Text);
                    comm.Parameters.AddWithValue("@val4", textBox4.Text);
                    comm.Parameters.AddWithValue("@val5", textBox5.Text);
                    comm.Parameters.AddWithValue("@val6", tb6);
                    comm.Parameters.AddWithValue("@val7", tb7);
                    comm.Parameters.AddWithValue("@val8", tb8);
                
                    conn.Open();
                        comm.ExecuteNonQuery(); //New method here, scalar does not really add multiple datas
                    conn.Close(); 

                }
            }


            label3.Visible = true;

            
        }

   

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 load = new Form1();
            load.Show();
            this.Close();
        }

        private void Add_Load(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
