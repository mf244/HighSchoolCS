﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration; 
using System.Data.SqlClient; 


namespace SeeSharpCode
{
    public partial class Remove : Form
    {

        string connectionString; 
        SqlConnection connection;
        public Remove()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["SeeSharpCode.Properties.Settings.BasicBusinessConnectionString"].ConnectionString;

        }

        private void button1_Click(object sender, EventArgs e)
        {
            connection = new SqlConnection(connectionString);
            connection.Open(); 

            int empID = Convert.ToInt32(textBox1.Text);

            object empName = ExecuteScalar(connectionString, "SELECT Name FROM EmpInfo WHERE EmployeeID = "+empID); 

           //Creates an "Are you sure" message box
            string message = "Are you sure you want to terminate "+empName+"?";
            string title = "Terminate Employee";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result = MessageBox.Show(message, title, buttons);

            if (result == DialogResult.Yes)
            {
                ExecuteScalar(connectionString, "DELETE FROM EmpInfo WHERE EmployeeID = " + empID); //Uses delete statement to delete entire row

                label2.Text = empName + " has been terminated";
            }
            else
            {
                label2.Text = "no employee has been terminated";
            }

           
            connection.Close(); 
        }

         public static Object ExecuteScalar(String connectionString, String commandText)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            { //These using statements allow the scalar (get data) to have the DB connection, essentially a more complicated conn.Open
                using (SqlCommand cmd = new SqlCommand(commandText, conn))
                {
                    

                    conn.Open();
                    return cmd.ExecuteScalar(); //Returns the result of the object connected to the DB with the SQL command
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Form1 load = new Form1();
            load.Show();
            this.Close();
        }

        private void Remove_Load(object sender, EventArgs e)
        {

        }
    }
}
