﻿SELECT Name FROM EmpInfo WHERE Id = 4;

SELECT EmployeeID FROM EmpInfo WHERE Name = Greg Macca;

SELECT * FROM EmpInfo;