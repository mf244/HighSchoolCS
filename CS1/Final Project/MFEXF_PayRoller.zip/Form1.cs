﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks; 
using System.Windows.Forms;
using System.Configuration; //All usings before these two standard. This using allows the system to view the built in DB file
using System.Data.SqlClient; //This allows functionality for the database to be queried, add/remove/change etc...

namespace SeeSharpCode //This is a tribute to the tutorial I watched to learn the basics of databases
{
    public partial class Form1 : Form
    {
        string connectionString; //Initializes two variables you will learn more about later to be used in multiple methods
        SqlConnection connection; 
        public Form1()
        {
            InitializeComponent();

            connectionString = ConfigurationManager.ConnectionStrings["SeeSharpCode.Properties.Settings.BasicBusinessConnectionString"].ConnectionString; 
            //The variables we just created are turned into meaningful code, telling the computer how to connect to the database and talk to it.
        }

        private void empInfoBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {


        }

        private void Form1_Load(object sender, EventArgs e) //Example code here to show how a name would be queried
        {
            
            /*
            connection = new SqlConnection(connectionString); //Sets up a new connection
            connection.Open(); //Opens a new connection to the ConnectionString (the DB)

            object data = ExecuteScalar(connectionString, "SELECT Name FROM EmpInfo WHERE Id = 2"); 
            //This is the line where the SQL statement is set, this is the command that will be run against the DB


            connection.Close(); //Closes the connection to DB to prevent data loss

            */
        }

        /*
        public static Object ExecuteScalar(String connectionString, String commandText)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            { //These using statements allow the scalar (get data) to have the DB connection, essentially a more complicated conn.Open
                using (SqlCommand cmd = new SqlCommand(commandText, conn))
                {


                    conn.Open();
                    return cmd.ExecuteScalar(); //Returns the result of the object connected to the DB with the SQL command
                }
            }
        }
        */
        private void button1_Click(object sender, EventArgs e) //These three lines are repeated alot and open a new form then close/hide the current
        {
            Indiv load = new Indiv();
            load.Show(); 
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            Mast load = new Mast();
            load.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Add load = new Add();
            load.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Remove load = new Remove();
            load.Show();
            this.Hide();
        }
    }
}


