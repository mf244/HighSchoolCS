﻿SELECT SUM(Rate*Hours) FROM EmpInfo;

SELECT * FROM EmpInfo;