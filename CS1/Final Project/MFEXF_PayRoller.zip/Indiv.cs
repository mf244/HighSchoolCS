﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration; 
using System.Data.SqlClient; 

namespace SeeSharpCode
{
    public partial class Indiv : Form
    {



        string connectionString = ConfigurationManager.ConnectionStrings["SeeSharpCode.Properties.Settings.BasicBusinessConnectionString"].ConnectionString; //The var is given data, esentially this is how to connect to the database
        SqlConnection connection;

        public Indiv()
        {
            InitializeComponent();
        
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 load = new Form1();
            load.Show();
            this.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            long empID = Convert.ToInt64(textBox1.Text);
            connection = new SqlConnection(connectionString);
            connection.Open(); 


            FillTable(empID); //calls the fill table method with enployee ID entered

            connection.Close(); 

        }

        public void FillTable(long EID)
        {
            connection = new SqlConnection(connectionString);
            connection.Open(); 

            //Each of the following lines assigns a single cell from the employee's row to its own object
            object name = ExecuteScalar(connectionString, "SELECT Name FROM EmpInfo WHERE EmployeeID = " + EID); 
            object id = ExecuteScalar(connectionString, "SELECT EmployeeID FROM EmpInfo WHERE EmployeeID = " + EID); 
            object grade = ExecuteScalar(connectionString, "SELECT PayGrade FROM EmpInfo WHERE EmployeeID = " + EID); 
            object address = ExecuteScalar(connectionString, "SELECT Address FROM EmpInfo WHERE EmployeeID = " + EID); 
            object hourly = ExecuteScalar(connectionString, "SELECT Hourly FROM EmpInfo WHERE EmployeeID = " + EID); 
            object rate = ExecuteScalar(connectionString, "SELECT Rate FROM EmpInfo WHERE EmployeeID = " + EID); 
            object hours = ExecuteScalar(connectionString, "SELECT Hours FROM EmpInfo WHERE EmployeeID = " + EID); 
            object yearly = ExecuteScalar(connectionString, "SELECT Yearly FROM EmpInfo WHERE EmployeeID = " + EID); 

           //These lines set the data to strings (just in case it isn't already) then displays them in the labels
            lblName.Text = Convert.ToString(name);
            lblID.Text = Convert.ToString(id);
            lblPG.Text = Convert.ToString(grade);
            lblAddress.Text = Convert.ToString(address);
            lblHour.Text = Convert.ToString(hourly);
            lblRate.Text = Convert.ToString(rate);
            lblHours.Text = Convert.ToString(hours);
            lblYear.Text = Convert.ToString(yearly);

            lblName.Visible = true;
            lblID.Visible = true;
            lblPG.Visible = true;
            lblAddress.Visible = true;
            lblHour.Visible = true;
            lblRate.Visible = true;
            lblHours.Visible = true;
            lblYear.Visible = true;

            connection.Close(); 
        }

         public static Object ExecuteScalar(String connectionString, String commandText)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            { //These using statements allow the scalar (get data) to have the DB connection, essentially a more complicated conn.Open
                using (SqlCommand cmd = new SqlCommand(commandText, conn))
                {
                    

                    conn.Open();
                    return cmd.ExecuteScalar(); //Returns the result of the object connected to the DB with the SQL command
                }
            }
        }

        private void button3_Click(object sender, EventArgs e) //This is the method that changes a cell
        {
            long empID = Convert.ToInt64(textBox1.Text); //Gets Employee ID again
            connection = new SqlConnection(connectionString);
            connection.Open(); 
            string x = textBox2.Text; //sets column name
            string y = textBox3.Text; //new data

            ExecuteScalar(connectionString, "UPDATE EmpInfo SET "+x+" = "+y+" WHERE EmployeeID = " + empID); //Usage of the UPDATE SQL statement

            FillTable(empID); //refreshes all the labels by calling fill method again

            connection.Close();

        }

        private void label11_Click(object sender, EventArgs e)
        {

        }

        private void Indiv_Load(object sender, EventArgs e)
        {

        }
    }
}
