﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX53_Slotz
{
    public partial class MFEX53_Slotz : Form
    {
        public MFEX53_Slotz()
        {
            InitializeComponent();
            //I could have done this but schnaw
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
        int tokens = 100; //This works aparrently, i have learned you can initialize variables out here
        public void button1_Click(object sender, EventArgs e)
        {
            tokens--;
            Random randy = new Random();
            
            int wheel1 = randy.Next(1, 4);
            label1.Text = Convert.ToString(wheel1);//I learned you need to convert these to strings
            
            int wheel2 = randy.Next(1, 4);
            label2.Text = Convert.ToString(wheel2);
            
            int wheel3 = randy.Next(1, 4);
            label3.Text = Convert.ToString(wheel3);


            if (wheel1 == 1 && wheel2 == 1 && wheel3 == 1)
            {
                tokens += 4; //I learned the usage of +=, would have been better to know earlier
                label6.Text = "You won: 4 tokens";
            }
            else if (wheel1 == 2 && wheel2 == 2 && wheel3 == 2)
            {
                tokens += 8;
                label6.Text = "You won: 8 tokens";
            }
            else if (wheel1 == 3 && wheel2 == 3 && wheel3 == 3)
            {
                tokens += 12;
                label6.Text = "You won: 12 tokens";
            }
            else
            {
                label6.Text = "You won: 0 tokens :(";
            }

            label6.Visible = true;
            label5.Text = Convert.ToString(tokens);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }
    }
}
