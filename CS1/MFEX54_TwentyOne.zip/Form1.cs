﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX54_TwentyOne
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        int player = 0; //Initializing these in no mans land makes them global
        int dealer = 0;
        int draw = 0;
        
        private void button1_Click(object sender, EventArgs e)
        {
            
            if (textBox1.Text != "")
            {
                Random randy = new Random();
                int numCards = Convert.ToInt32(textBox1.Text);
                string yourCards = "Player's Numbers: ";
                int sumPlayer = 0; //Realized i needed sum for each set as well as the string
                string dealersCards = "Dealer's Numbers: ";
                int sumDealer = 0;

                for (int i = 1; i <= numCards; i++)
                {
                    int card = randy.Next(1, 11); 
                    yourCards = yourCards + card + " ";
                    sumPlayer += card;

                }
                for (int i = 1; i <= 3; i++)
                {
                    int card = randy.Next(1, 11);
                    dealersCards = dealersCards + card + " ";
                    sumDealer += card;
                }

                label5.Text = "Player's sum: " + sumPlayer + " Dealer's sum: " + sumDealer; //This started as a debug but idecided it would be useful
                label3.Text = dealersCards;
                label2.Text = yourCards;
                string outcome = GetOutcome(sumPlayer, sumDealer);//Used a method here to make you happy
                label4.Text = "Winner: " + outcome;


                if (outcome == "Player :)")
                {
                    player++;
                }
                else if (outcome == "Dealer :(")
                {
                    dealer++;
                }
                else if (outcome == "Draw :/")
                {
                    draw++;
                }

                Counters.Text = "Player wins: "+player+"\nDealer wins: "+dealer+"\nDraws: "+draw;
            }
            
            
        }

        public string GetOutcome(int sp, int sd)
        {
            string outcome = "";
            if (sp>21&&sd>21)
            {
                //draw
                outcome = "Draw :/";
            }
            else if (sp==sd && sp <=21 && sd <=21)
            {
                //draw
                outcome = "Draw :/";
            }
            else if (sp<sd && sd<=21)
            {
                //winner dealer
                outcome = "Dealer :(";
            }
            else if (sp>sd && sp<=21)
            {
                //winner player
                outcome = "Player :)";
            }
            else if (sp>21&&sd<=21)
            {
                //winner dealer
                outcome = "Dealer :(";
            }
            else if (sd>21&&sp<=21)
            {
                //winner player
                outcome = "Player :)";
            }
            return outcome;
        }
        
        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}

/*
 Create an application(windows form or console) called EX54_TwentyOne.  Write code to simulate a simplified version of the game "21."
Basic rules as follows: A deck of cards numbered 1 to 10 is used and any number can be repeated.  The computer starts by asking you 
(the user) how many cards you want.  It then deals you that amount of cards,  which are randomly picked.  It then deals itself three 
randomly picked cards.  If both scores are over 21, or if both are equal but under 21, the game is declared a draw.  Otherwise, the 
winner is the one with the highest score equal to or less than 21.  If one score is over 21,  but the other is 21 or less, the player 
with 21 or less is declared the winner. 

Write the program so that the game can be played as often as desired with the winner of an individual round winning one point. 
At the end of the games display the total winning rounds for you and the computer and the number of draws.  
 */
