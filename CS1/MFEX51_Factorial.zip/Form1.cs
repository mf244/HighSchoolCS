﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace MFEX51_Factorial
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label2.Text = "Enter a number to find it's factorial.\n The number must be between 0 and 23 (inclusive).";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            long factorial = 0;

            long input = Convert.ToInt64(textBox1.Text); //I had int32 here after I changed it to a long, but I fixed it
            
            if (input < 0 || input > 23)
            {
                MessageBox.Show("Error!");
            }
            else if (input == 0)
            {
                factorial = 1;
            }
            else if (input > 0&& input <= 23)
            {
                factorial = FindFactorial(input);
                label1.Text = input + "! = " + factorial;
            }

           
        }

        public long FindFactorial(long input)
        {
            long sum = 1;//Isabella helped me learn this
            for (long i = 1; i <= input; i++)//I had so maby things wrong in here, I got it eventually though and learned from my mistakes
            {
                sum = sum * i;
            }
            return sum;
        }
    }
}
