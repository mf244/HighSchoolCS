﻿/*
 * Name: Matthew Floyd
 * Date: 11/18/22
 * Program Name: Ex19_Arrays3_WindowsForms
 * Prompt: Create a windows application that will take a string entered in a
 * textbox and have it displayed in a label all uppercase. This program should include a
 * function that YOU CREATE called MakeUppercase() not the one that Microsoft has created
 * ( i.e. you can't use .ToUpper()). MakeUppercase() should have a string argument and return a string all in uppercase letters.
 */

//Please note I was sick when i wrote this at home

using System;
using System.Windows.Forms;

namespace MFEx19_Arrays3_WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        public static String ConvertToUpperCase(String input)//Here is my budget convert method
        {
            String output = "";//Initializes the output var
            for (int i = 0; i < input.Length; i++)
            {
                if (input[i] >= 'a' && input[i] <= 'z')//Checks if the char in the array is between and z
                {
                    output += (char)(input[i] - 'a' + 'A');//Adds the uppercase letter to the array
                }
                else
                    output += input[i];//Anything that's not a-z get added right back
            }
            return output;//Returns the ouput of the program
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

            String input = textBox1.Text;//Gets the input from the text box
            string output = ConvertToUpperCase(input);//Uses the budget convert method
            label2.Text += "\n"+output;//Writes the string to the label
            
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
