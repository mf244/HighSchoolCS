﻿using System;
using System.Windows.Forms;

/*
 * Name: Matthew Floyd
 * Date: 11/22/22
 * Project Name: Ex20_Arrays4_WindowsForms
 * Prompt: Create a windows application that will take a word entered in a textbox and have it displayed in a label reversed. 
 * The program should include function that YOU created called MakeReverse(). MakeReverse() will return the reverse of its single string argument.
For example, if the argument is "I love CS2" it should return "2SC evol I". Additionally, in some way indicate if the statement entered is a palindrome.
 */
namespace MFEx20_Arrays4_WindowsForms
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string beforeReverse = textBox1.Text;

            string afterReverse = MakeReverse(beforeReverse);//Calls the method to reverse the text

            label2.Text += "\n" + afterReverse;//Writes to the label, I made this write all outputs so you could see like a history

            if (beforeReverse == afterReverse)//Checks if both are equal to display a message box if there is a palindrome found
            {
                MessageBox.Show(beforeReverse+" is a palindrome!");
            }
        }

        public static string MakeReverse(string b4Rev)
        {
            char[] charray = b4Rev.ToCharArray();//Uses a char array to be able to reverse string
            string afterRev = "";
            for (int i = charray.Length - 1; i > -1; i--)//Goes through each index in reverse
            {
                afterRev += charray[i];//Adds to the new string from the index place in the for loop
            }
            return afterRev;
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
